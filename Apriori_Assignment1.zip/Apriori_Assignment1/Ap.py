#!/usr/bin/python
import csv
import collections
import sys
import itertools

#Open file and read & everyword has a list of transaction and read support

def main():
    Trans = []
    with open('trump_tweets_2016_processed.csv', 'r') as myfile:
        file = myfile.read()
        #start readin from the start of the charecter
        myfile.seek(0)
        for row in myfile:
            split = row.split()
            Trans.append(split)
        myfile.close()
    Sup = int(sys.argv[2])
    Apriori_wordseq(Trans, file, Sup)


def Apriori_wordseq(Trans,data,Sup):
    #Iterate through this list of transactions and count number of occurences of every word
    c = collections.Counter()
    for r in Trans:
        c.update(r)
    #splitting words as string
    #print (r)
    #Prune all words that do not have supply in Counter
    itms = {s:c[s]
        for s in c
            if c[s] >= Sup}
    #list the single items
    print("Pass 0: " + str(itms))
    #Get all remaining words from Counter and make permutations of length 2 using permutations
    keys = list(itms.keys())
    Candidate = list(itertools.permutations(keys, 2))
    itms = {" ".join(s):data.count(" ".join(s))
        for s in Candidate
            if data.count(" ".join(s)) >= Sup}
    #get all two seq and pass2 and pass 3
    print("Pass 1: " + str(itms))
    #Check if these candidates are actually in the file, if not, prune:
    #generate permutations, until no support
    i = 3
    while itms:
        keys = list(itms.keys())
        tmp = [s.split() for s in keys]
        #print (tmp)
        l = [item for sublist in tmp
             for item in sublist]
        u = list(set(l))
        
        Candidate = list(itertools.permutations(u, i))
        itms = {" ".join(s):data.count(" ".join(s))
            for s in Candidate
                if data.count(" ".join(s)) >= Sup}
        print("Pass {}: {}".format(i-1, str(itms)))
        i += 1


#call main
main()
